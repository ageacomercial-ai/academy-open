# BUG_MAP — Motor Acadêmico ACADEMY

> Formato por bug: título, severidade P0-P3, arquivo/função/linha, causa, efeito, reprodução, correção recomendada. Não corrigido neste pacote.

---

```
BUG-001
Título: Geração acadêmica baseada em template fixo (fallback local)
Severidade: CRÍTICA (P0)
Arquivo: js/generator.js
Função: _blocosFb() (linha 869-874, chamada em iniciarGer quando attempts>=4 ou AI_INDISPONIVEL)
Causa: Fallback injeta ${s.toLowerCase()} em 2 frases hardcode: "A literatura indica que X é dimensão central. Segundo Silva (2020)..." + "Santos (2019) argumenta que X não se dissocia... A evidência indica que..." com [CITAÇÃO A VERIFICAR]/[DADO A VERIFICAR COM FONTE PRIMÁRIA] mas entrega como PRONTO.
Efeito: Documento com citações fictícias Silva/Santos exportável como FINAL se gate não pegar órfãs.
Reproduzir: Desconectar IA ou forçar 4 retries → iniciarGer({tema:"Gestão"}) → sec.paragraphs contém Silva (2020) sem source_id.
Correção: Remover _blocosFb ou marcar bloco como DRAFT+bubble error e bloquear canExportFinal.
```

```
BUG-002
Título: Citação sem fonte correspondente chega ao PDF
Severidade: CRÍTICA (P0)
Arquivo: api/engine.js:792-811 (STRICT gate), js/generator.js:869, academic/prompts/system.js:9
Função: Gate STRICT só em academic/engines/integrity-pipeline + montagem font.contexto vazio
Causa: Prompt exige "OBRIGATÓRIO 1 citação/parágrafo" mas font. queSustentamClaim=[] → LLM inventa Santos (2019); extrairCitacao aceita; bloqueia só se ACA_INTEGRITY_MODE==='STRICT' e autor não em verifiedAuthors.
Efeito: 11 citações → 2 refs (caso 60/11→2), 9 órfãs saem em PDF FINAL.
Reproduzir: Gerar capítulo com tema sem fontes verificáveis em modo não-STRICT → citar Santos (2019) sem source_id.
Correção: computeFinalGate já adicionado (orphanCitations>0 → bloqueia); garantir STRICT default e remover fallback.
```

```
BUG-003
Título: Placeholder exportado como conteúdo final
Severidade: ALTA (P1)
Arquivo: api/engine.js:734,810 ; js/generator.js:869 ; academic/prompts/chapters.js:33
Função: font. Contexto vazio → "Use [CITAÇÃO A VERIFICAR]" + replace gate
Causa: Placeholder é string visível; sanitizarConteudo não remove; integridadepipeline transparencia=1 hardcoded não conta; export só checava rep.blocked.
Efeito: [CITAÇÃO A VERIFICAR]/[DADO A VERIFICAR COM FONTE PRIMÁRIA] impresso no PDF/DOCX.
Reproduzir: Gerar doc com 0 fontes verificadas → parágrafos contêm [CITAÇÃO A VERIFICAR] → expPDF → PDF contém placeholder.
Correção: computeFinalGate cita citationWithoutEvidence; renderIntegrityPipelinePanel lista reasons; watermark DRAFT.
```

```
BUG-004
Título: Referência bibliográfica sem source real (refGerarFallback)
Severidade: ALTA (P1)
Arquivo: js/export.js:93 refGerarFallback() ; academic/prompts/references.js:57 peneirarReferencias
Função: refGerarFallback retorna 10 refs hardcode (World Bank, UNESCO, Santos 2018, Mbembe 2016...)
Causa: Quando refValidar <REF_MIN 8 ou LLM falha, export injeta fallback sem verificação; peneirar valida só forma.
Efeito: Bibliografia com refs fictícias plausíveis sem DOI/source_id.
Reproduzir: secs com 0 refs → expPDF → modal "Gerar refs" → fallback World Bank etc no PDF.
Correção: Em STRICT retornar strict-empty (0 refs) + bloquear FINAL até refs verificadas (útil já em doReferencias:977).
```

```
BUG-005
Título: Corrupção textual por reparo JSON + sanitização
Severidade: ALTA (P1)
Arquivo: api/engine.js:75 repararAST, 1664 extrairJSON/blocosBalanceados ; js/export.js:11 sanitizarConteudo
Função: repararAST tenta JSON→regex→raw→default; extrairJSON pega último bloco sections; sanitizar regex over-greedy
Causa: max_tokens truncado → JSON cortado → reparo raw split por ^\d+\.\d+ perde; sanitizar replace {\s*"chapter_id"... deleta parágrafo legítimo com JSON exemplo; \\" desescapa.
Efeito: Textos Fsquisa/Santcxs/pmblema, parágrafos curtos dropados p.length>15, dados perdidos PBE slice.
Reproduzir: Gerar capítulo com palavras>4000 e maxTok 6000 → truncamento → repararAST _repaired + perda.
Correção: Aumentar maxTok 12000, json_object garantido, blocosBalanceados com single-quote, sanitizar só fora de blocos código.
```

```
BUG-006
Título: EXTRAIR citação/referência com regex falha (INE, 2024)
Severidade: ALTA (P1)
Arquivo: academic/engines/evidence.js:33 extrairCitacao ; academic/prompts/references.js:57 peneirar ; js/generator.js:264 extrairAutoresCitados
Função: Regex 1[0-9]{3} sem 19xx, [A-Z]{2,} sem vírgula, grupos m[2]+m[3] errados
Causa: extrairCitacao falha em (INE, 2024) uppercase; peneirar rejeita Apelido, I. (Ano); extrairAutoresCitados concatena errado.
Efeito: Cit. não detectada → não entra em autoresCitados → refs vazias → órfãs; refs válidas rejeitadas.
Reproduzir: Texto "Segundo INE (2024)..." → extrairCitacao retorna null; refs "Silva, A. (2020). Obra." → peneirar invalidas>0.
Correção: Regex unificado /\(.*\b(19|20)\d{2}\b.*\)/ + author parse com/sem vírgula, testes evidence.test.mjs.
```

```
BUG-007
Título: Verificação inflada (falso partially_verified)
Severidade: CRÍTICA (P0)
Arquivo: academic/engines/verification.js:11 verificarReferenciaOnline
Função: Fallback estrutural if(title&&author&&year) return partially_verified sem consultar CrossRef
Causa: Quando CrossRef 429/timeout, cai no fallback forma.
Efeito: Ref fictícia "Silva (2020). Obra Inventada." marcada partially_verified → score 60 não bloqueia.
Reproduzir: Mock fetch CrossRef 429 → verificarReferenciaOnline({title:"Obra Inventada",author:"Silva",year:2020}) → partially_verified.
Correção: Só retornar unverified/needs_review se sem resposta API; retry com backoff.
```

```
BUG-008
Título: Persistência source_claims best-effort perde rastreabilidade
Severidade: CRÍTICA (P0)
Arquivo: api/engine.js:715 fetch source_claims, 731 SOURCE_ID prompt
Função: fetch com Abort 4s + catch(()=>{}) silencioso
Causa: Supabase down → capítulos com DIRECTLY_SUPPORTS sem linha source_claims; evidence_text truncado 500.
Efeito: CLAIM→EVIDENCE→SOURCE sem FK, auditoria impossível, page sempre null.
Reproduzir: SUPABASE_URL inválido → doCapitulo gera capítulo com fontesQueSustentamClaim mas source_claims vazio.
Correção: Tornar persistência obrigatória ou marcar capítulo DRAFT se falhar, page/section null explícito já correto.
```

```
BUG-009
Título: Repetit. estrutural por PERFIL + POOLS determinísticos
Severidade: MÉDIA (P2)
Arquivo: academic/prompts/system.js:9 PERFIL_NIVEL, 130 POOLS_ANTI_IA, academic/prompts/chapters.js:38
Função: PERFIL_NIVEL 4 templates "Segundo Cardoso (2019)", POOLS pick (n*7+s*3)%len
Causa: Instrução fixa + exemplo com estatísticas 15%/3.2% (ineficaz anti-IA), rotação previsível.
Efeito: Capítulos com "A literatura indica que X é dimensão central" repetido por subtópico.
Reproduzir: Gerar 3 capítulos mesmo tema/nivel → comparar paragraphs → similaridade >0.85.
Correção: Diversificar ABORDAGENS[5] já existe, mas remover example com %; POOLS com seed random.
```

```
BUG-010
Título: CONTAGEM citações→refs desacoplada (11→2) não bloqueava FINAL
Severidade: CRÍTICA (P0)
Arquivo: academic/engines/integrity-pipeline.js:56,132 ; js/academic-ui.js:341 ; js/export.js:286
Função: report.blocked=critical>0&&isStrict(); render?blocked:✓Pronto; _expPDF: if(rep.blocked)
Causa: Gate só crítico/fabricated/score<40; órfãs=9 ignoradas; UI e export recalculavam divergente.
Efeito: Caso real 60/11→2, 34% quality, no_objectives, 9 arg issues saiu FINAL.
Reproduzir: test/inconsistencia-FINAL-gate.test.mjs (11 cit 2 refs, highCritical 4) → old gate permite.
Correção: computeFinalGate 7 regras + canExportFinal fonte única (IMPLEMENTADO 016e9a7).
```

```
BUG-011
Título: Schema drift CLAIM_TYPES duplicado
Severidade: MÉDIA (P2)
Arquivo: academic/engines/claims.js:7 (9 tipos STATISTICAL...) vs academic/schemas/evidence.schema.js:30 (5 tipos fact/interprétation...)
Função: extrairClaims vs classificarAfirmacao
Causa: Duas taxonomias paralelas confundem requires_source/requires_numeric_evidence vs MATRIX FACT.
Efeito: Claim STATISTICAL pode ser classificado INTERPRETATION → severidade errada.
Reproduzir: extrairClaims("37% dos...") → STATISTICAL requires_numeric, mas classificarAfirmacao → INTERPRETATION se sem padrão.
Correção: Unificar taxonomy ou mapear 9→5.
```

```
BUG-012
Título: health/readiness/confidence divergem do integrity
Severidade: BAIXA (P3)
Arquivo: api/engine.js:172 calcularDocumentHealth, 220 calcularReadiness, 251 calcularConfidence
Função: Health penaliza _repaired -10, readiness "Pronto para entrega" verifica paras min, confidence retries
Causa: Scores locais não alimentam computeFinalGate; health 85 Saudável pode coexistir com blocked true.
Efeito: UI docHealthPanel "Pronto para entrega" enquanto integridade REVISAR.
Reproduzir: Cap _repaired com paras 12 → readiness.ready true + blocked true.
Correção: Consolidar readiness com canExportFinal.
```

