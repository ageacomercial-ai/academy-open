# TEST_CASES — Motor Acadêmico ACADEMY

> Casos sem implementação, para agente seguinte. Cobrem citações, placeholders, corrupção, órfãs, repetição, gate.

---

### TC-001 — Citação inexistente (Santos 2019 sem fonte)

Entrada:
```
Texto: "Santos (2019) argumenta que X..."
Refs: []
Sources buscadas: 0 verificadas
```
Passos:
1. `extrairCitacao` detecta `Santos (2019)`
2. `searchAll("Santos 2019") → []`
3. `doCapitulo` fontesContexto = "NENHUMA FONTE..."
Esperado: **FAIL** — `computeFinalGate` bloqueia (`orphanCitations 1`, `reviewRequired 1`), `canExportFinal=false`, UI `🚫 NÃO PRONTO`.

---

### TC-002 — Placeholder no corpo

Entrada:
```
Parágrafo: "A evidência indica que ... [DADO A VERIFICAR COM FONTE PRIMÁRIA]."
```
Esperado: **FAIL** — `integrity-pipeline steps.statistics.semFonte++`, `computeFinalGate blocked`, export `DRAFT`.

---

### TC-003 — Texto corrompido

Entrada:
```
"Fsquisa Santcxs pmblema s%bre recom"
```
Esperado: **FAIL** — `repararAST` deve penalizar `confidence<60` + `health<60` + gate `corruption` → `canExportFinal=false`. (Se truncamento, `_repaired=true`).

---

### TC-004 — Citação sem referência (órfã)

Entrada:
```
Citações: 11 (Silva 2020×4, Santos 2019×7)
Referências: 2 (Silva 2020, Santos 2021)
```
Esperado: **FAIL** — `getOrphanCitations=9`, `computeFinalGate blocked` (referência sem source).

---

### TC-005 — Referência sem fonte (inventada)

Entrada:
```
Ref: "Santos, B. de S. (2018). O fim do império cognitivo. Autêntica."
Verificação CrossRef: needs_review/unverified
```
Esperado: **FAIL** — `verificarReferenciaOnline` → `unverified`, `verifyRate 0%<50` → `referenceWithoutSource`.

---

### TC-006 — Repetição estrutural

Entrada:
```
Cap. 1 sec 1: "A literatura indica que gestão é dimensão central. Segundo Silva (2020)..."
Cap. 1 sec 2: "A literatura indica que liderança é dimensão central. Segundo Silva (2020)..."
```
Esperado: **WARNING/FAIL** se similaridade Jaccard >0.85 entre parágrafos → `argumentation issues high`.

---

### TC-007 — Trabalho válido (E2E happy path)

Entrada:
```
Tema: "Gestão escolar Angola" nivel mestrado
Sources: 3 verificadas DIRECTLY_SUPPORTS, evidence_text contém números 37%, 42%
Citações: 6 → Refs: 6 (todas verified)
Coverage: completo, quality 78%
```
Esperado: **PASS** — `canExportFinal=true`, `✓ Pronto para exportação FINAL`, sem watermark.

---

### TC-008 — Número factual sem evidência numérica

Entrada:
```
Claim: "37% das empresas usam IA" requires_numeric_evidence=true
Evidence: "empresas usam IA" sem "37%"
```
Esperado: **FAIL** — `verifyClaimSupport → NOT_VERIFIED` + `numsSemFonte 1` → `computeFinalGate blocked`.

---

### TC-009 — CLAIM fact sem DIRECTLY/PARTIALLY

Entrada:
```
4 FACT UNVERIFIED (Santos 2019 etc), support NOT_VERIFIED
```
Esperado: **FAIL** — `gerarRelatorioIntegridade reviewRequired=4 highCritical=4` → `canExportFinal=false`.

---

### TC-010 — Cobertura no_objectives

Entrada:
```
diagnostic.specificObjectives=[]
Chapters: ["Intro","Desenvolvimento"]
```
Esperado: **FAIL** — `analisarCobertura estado=no_objectives` → `computeFinalGate coverageEstado`.

---

### TC-011 — Qualidade 34% Insuficiente

Entrada:
```
Scorecard overall 34 (F), integrity 20, citations 10
```
Esperado: **FAIL** — `qualityOverall 34<50` → `canExportFinal=false` (caso 60/11→2 real).

---

### TC-012 — JSON truncado recupera via repararAST

Entrada:
```
AI raw: '{"chapter_id":"1","title":"Cap 1","sections":[{"title":"1.1 Tema","paragraphs":["Texto truncado...'
(max_tokens estourado, sem fechamento `]}`)
```
Esperado: **WARNING** — `extrairJSON` falha → `repararAST _repaired=true repair_reason no_json` → `completeness<60` → bloqueia FINAL mas permite DRAFT.

---

### TC-013 — Fallback local _blocosFb não deve ser FINAL

Entrada:
```
Simular 4 retries falhos → _blocosFb gera Silva (2020)/Santos (2019) templates
```
Esperado: **FAIL** — `_blocosFb` deve resultar `canExportFinal=false` + erro `AI_INDISPONIVEL` (não `PRONTO ⚠`).

---

### TC-014 — DOI falso na referência

Entrada:
```
Ref: "Silva, A. (2020). Título. doi:10.9999/falso.123"
CrossRef: unverified
```
Esperado: **FAIL** — `verificarListaReferencias` 0 verified → `score<90` + `referenceWithoutSource`.

---

### TC-015 — Tabelas sem dataset

Entrada:
```
Texto contém "<table> Tabela 1" mas datasets=[]
```
Esperado: **FAIL** (P1) — `steps.tables.temTabela true rastreavel 0 → warnings++` + se `isStrict` e empíricos → `fabricatedData`.

---

### TC-016 — Fonte existe mas não sustenta (DOES_NOT_SUPPORT)

Entrada:
```
Claim "mercado cresceu 10M" vs Evidence "mercado estagnado"
verify ratio <0.15
```
Esperado: **FAIL** — `support_status DOES_NOT_SUPPORT` → `canExportFinal=false`.

---

### TC-017 — Coerência metadata (n=100 vs dataset 47)

Entrada:
```
Metodologia "n=100 participantes" + dataset row_count 47 + resultados "62% preferem X"
```
Esperado: **FAIL** — `critical++` metod. mismatch (pipeline atual só detecta 0, mas caso deve falhar por row mismatch).

---

### TC-018 — Gate fonte única não diverge

Entrada:
```
Report score 60, blocked false, orphan 9, highCritical 4
Chamar validar_integridade e analisar_documento mesmo doc
```
Esperado: **PASS se** `validar_integridade.canExportFinal === analisar_documento inferido canExportFinal` — ambos usam `computeFinalGate`.

---

Mais casos: ver `test/inconsistencia-FINAL-gate.test.mjs` (caso real 60/11→2) e `test/integrity.test.mjs` T1-T10.
