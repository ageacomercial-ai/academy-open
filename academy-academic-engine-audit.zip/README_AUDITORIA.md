# ACADEMY — Motor Acadêmico — README de Auditoria

> Pacote isolado para análise por agente externo. **Nenhuma correção foi aplicada no projeto principal.** Este documento consolida auditoria → dependências → pipeline → bugs → casos de teste.

## A. Visão Geral

Módulo responsável por gerar **trabalhos acadêmicos completos** (TFC, monografia, dissertação) a partir de `tema, curso, nível, tipo de trabalho, objetivos`. Orquestra `planejamento → pesquisa de fontes reais → geração capítulo-a-capítulo via LLM com EVIDENCE-FIRST → citações/referências → validação → Quality Gate → exportação PDF/DOCX`.

Modo `ACADEMIC_INTEGRITY_MODE=STRICT` ( `academic/policies/integrity.js:9` ) proíbe inventar `autores, DOI, estatísticas, entrevistas, tabelas` — prefere `[CITAÇÃO A VERIFICAR]`.

Stack: **Vercel (api/engine.js) + OpenRouter (ai-router.js) + 5 providers de busca (OpenAlex, Crossref, SemanticScholar, EuropePMC, OpenLibrary) + Supabase (source_claims/datasets)**.

---

## B. Pipeline Atual

```
INPUT (State.cfg: tema, curso, nivel, tipo, area, pags, inst, prof, metodologia)
  ↓  js/generator.js:iniciarGer() / js/screens-flow.js → callAcademyAPI()
PLANEJAMENTO
  ↓  api/engine.js:doPlano() / doEstrutura() → academic/prompts/structure.js: montarPromptPlano/Estrutura → callAI → extrairJSON → plano_academico {objetivos, capítulos, subs}
↓
PESQUISA (por capítulo)
  ↓  api/engine.js:doCapitulo() EVIDENCE-FIRST (linha 644):
       academic/engines/claims.js:extrairClaims(tema,[capTit+subs],objetivo) → {id,text,claim_type,requires_source,requires_numeric_evidence}
       → gerarQueries(claim) 2-3 queries/claim
       → academic/engines/search.js:searchAll(q,{limit:3}) paralelo 5 providers, dedup Jaccard 0.85, rankSources (L1 JOURNAL 10)
       → fontesEncontradas[0..12] com source_id=doi||isbn||url||provider:title:year
↓
FONTES / VERIFY
  ↓  academic/engines/verification.js:verificarReferenciaOnline() — CrossRef by DOI, title+author (score≥0.7 verified), OpenLibrary ISBN, fallback estrutural
       → fontesBibliograficamenteVerificadas[]
↓
EVIDÊNCIA
  ↓  academic/engines/retrieval.js:retrieveSource() (OA→Unpaywall→EuropePMC→abstract) → extractEvidence(source,claim) {evidence_text: abstract.slice(0,400), page:null}
       → verifyClaimSupport(claim,evidence) → DIRECTLY_SUPPORTS >0.6 / PARTIALLY >0.35 / DOES_NOT <0.15 / NOT_VERIFIED
       → api/engine.js:709 persist source_claims(source_id,claim_id,support_status,evidence_text,page=null) em Supabase (best-effort 4s)
       → fontesQueSustentamClaim = rankSources(...).slice(0,3)
       → fontesContexto string injetada no prompt
↓
GERAÇÃO
  ↓  academic/prompts/chapters.js:montarPromptCapitulo({tema,tipo,nivel,capNum,capTit,subs,geoCtx,escopo,fontesContexto,palavras,maxTok})
       + academic/prompts/system.js:PERFIL_NIVEL + POOLS_ANTI_IA
       → systemJSON schema {chapter_id,title,sections:[{section_id,title,paragraphs:3-5}]} + user prompt
       → api/ai-router.js:generate() Ollama→OpenRouter FREE → api/engine.js:callAI()
       → extrairJSON() / blocosBalanceados() → repararAST() (4 tentativas: JSON→regex→raw text→default)
       → Gate STRICT api/engine.js:792 substitui citações não verificadas por [CITAÇÃO A VERIFICAR]
       → calcularDocumentHealth/readiness/confidence/completeness → Quality Gate local (bloqueia se _repaired+completeness<60 ou paras<min)
↓
CITAÇÕES
  ↓  evidence.js:extrairCitacao() regex (Autor, Ano) / Autor (Ano) + generator.js:extrairAutoresCitados() 3 regex → DOC_MEMORY → montarPromptReferencias precisa autoresCitados
↓
REFERÊNCIAS
  ↓  api/engine.js:doReferencias() — tenta EVIDENCE-FIRST (searchAll→verificar→formatar APA sem LLM), se 0 e STRICT → strict-empty (0 refs), senão LLM montarPromptReferencias → peneirarReferencias (regex forma) → parseReferencias → validarListaReferencias
↓
VALIDAÇÃO / QUALITY GATE
  ↓  academic/engines/integrity-pipeline.js:runAcademicValidationPipeline() 15 etapas (citations, refs, claims, statistics numsSemFonte, datasets, methodology vs results, tables, fabricação, consistência, gerarRelatorioIntegridade)
       → score verificabilidade, blocked=critical>0&&isStrict(), label EXCELENTE/BOM/REVISAR/RISCO/NÃO PUBLICÁVEL
       → computeFinalGate() (7 regras) → canExportFinal/finalBlocked/finalReasons — FONTE ÚNICA
       academic/engines/quality.js:gerarScorecard() 8 critérios ponderados (coherence 20, argumentation 18, integrity 16, citations 14, coverage 12...)
       academic/policies/confidence-policy.js:gerarRelatorioIntegridade() MATRIX FACT×confidence → reviewRequired/highCritical/blocked
       academic/policies/coverage.js:analisarCobertura() objetivos↔capítulos → no_objectives se sem objetivos
↓
EXPORTAÇÃO
  ↓  js/export.js:expPDF()/expDocx()/expWord() → refGateExportacao(REF_MIN=8) → _expPDFExecutar() → validar_integridade (canExportFinal) → gerarJanelaPDF() (js/layout.js) com watermark DRAFT se bloqueado
       + js/academic-ui.js:renderIntegrityPipelinePanel() mostra 🚫 NÃO PRONTO PARA FINAL ou ✓ Pronto
```

Real: ver `ARCHITECTURE.md` (Mermaid) e `source/` neste ZIP.

---

## C. Arquivos Principais

| Arquivo | Responsabilidade | Importância |
|---|---|---|
| `source/api/engine.js` | Orquestrador Vercel: `doCapitulo` (EVIDENCE-FIRST), `doReferencias`, `doValidarIntegridade`, `repararAST`, `extrairJSON`, health/confidence/completeness, jobs | **CRÍTICA** |
| `source/api/ai-router.js` | Roteador IA: Ollama→OpenRouter FREE→fallback, `generate()`, `health()`, `estimateCost()`, model tiers | **CRÍTICA** |
| `source/academic/engines/integrity-pipeline.js` | Pipeline 15 etapas + `computeFinalGate()`/`deveBloquearExport()` — gate FINAL unificado | **CRÍTICA** |
| `source/academic/engines/search.js` | 5 providers busca, `dedup`, `rankSources`, `searchAll`, `source_id` | **ALTA** |
| `source/academic/engines/verification.js` | `verificarReferenciaOnline` (CrossRef/OpenLibrary), `verificarListaReferencias` | **ALTA** |
| `source/academic/engines/retrieval.js` | `retrieveSource`, `extractEvidence`, `verifyClaimSupport` | **ALTA** |
| `source/academic/engines/claims.js` | `extrairClaims`, `gerarQueries`, `deveExigirFonte` (EVIDENCE-FIRST taxonomy) | **ALTA** |
| `source/academic/engines/evidence.js` | `extrairAfirmacoes`, `extrairCitacao/Fonte`, `classificarAfirmacao`, `validarAfirmacoes` | **ALTA** |
| `source/academic/engines/quality.js` | `gerarScorecard` 8 critérios, `simularProfessor` | **MÉDIA** |
| `source/academic/engines/argumentation.js` | `analisarEstruturaArgumentativa`, `verificarCoerenciaArgumentativa` | **MÉDIA** |
| `source/academic/prompts/chapters.js` | `montarPromptCapitulo`, STRICT block, `fontesContexto` | **CRÍTICA** |
| `source/academic/prompts/references.js` | `montarPromptReferencias`, `peneirarReferencias` | **ALTA** |
| `source/academic/prompts/system.js` | `PERFIL_NIVEL/AREA`, `POOLS_ANTI_IA`, `gerarInstrucaoAntiIA` | **MÉDIA** |
| `source/academic/policies/confidence-policy.js` | MATRIX `FACT×confidence` → `gerarRelatorioIntegridade` | **ALTA** |
| `source/academic/policies/integrity.js` | `ACADEMIC_INTEGRITY_MODE`, `determinarEstadoDocumento` | **ALTA** |
| `source/js/generator.js` | Loop geração frontend, `DOC_MEMORY` 3 regex, `_blocosFb` fallback, `extrairAutoresCitados`, `validarQualidadeCapitulo` | **CRÍTICA** |
| `source/js/export.js` | `sanitizarConteudo`, `refDetectar/Validar/GerarFallback(10 refs hardcode)`, `expPDF/_expPDFExecutar` (watermark DRAFT), `expDocx` | **ALTA** |
| `source/js/academic-ui.js` | `analisarDocumento`, `renderIntegrityPipelinePanel` (gate UI), `validarIntegridade`, versioning | **ALTA** |
| `source/js/layout.js` | `gerarJanelaPDF` layout A4 premium, paginação PBE | **MÉDIA** |
| `source/js/state.js` | Store global `State` (`secs,cfg,diagnostic,refs`) | **MÉDIA** |
| `source/js/pbe.js` | Page Budget Engine `pbePlanear/pbeMedirPaginas` | **MÉDIA** |
| `source/supabase/migrations/0014_academic_integrity_strict.sql` | Schema `sources/claims/source_claims/datasets/results/generation_logs` | **ALTA** |

---

## D. Funções Principais

| Arquivo | Função | O que faz |
|---|---|---|
| `api/engine.js` | `doCapitulo(p)` | EVIDENCE-FIRST completo + prompt → callAI → repararAST → STRICT gate → health/readiness/confidence |
| `api/engine.js` | `doReferencias(p)` | Bibliografia EVIDENCE-FIRST ou LLM retry com `peneirarReferencias` |
| `api/engine.js` | `doValidarIntegridade(p)` | `runAcademicValidationPipeline` + `computeFinalGate` → `canExportFinal/mustBlockFinal` (fonte única) |
| `api/engine.js` | `repararAST(raw,capNum,capTit,subs)` | 4 níveis de reparo JSON→raw text→default, marca `_repaired` |
| `api/engine.js` | `extrairJSON(texto)` + `blocosBalanceados(s)` | Recupera JSON de resposta com CoT preamble |
| `api/engine.js` | `calcularDocumentHealth/readiness/confidence/completeness` | Scores locais (health, readiness `Pronto para entrega`, confidence, completeness) |
| `api/ai-router.js` | `generate(messages,opts)` | Seleciona provider `ollama→openrouter→existingFreeApi→openaiDirect`, `stream:false` |
| `academic/engines/search.js` | `searchAll(query,{limit,providers})` | Busca paralela 5 providers, `dedup`, `rankSources` |
| `academic/engines/verification.js` | `verificarReferenciaOnline(ref)` | CrossRef/OpenLibrary com timeout 8s, retorna `verified/partially_verified/needs_review/unverified` |
| `academic/engines/retrieval.js` | `verifyClaimSupport(claim,evidence)` | Ratio keywords + presença numérica → `DIRECTLY/PARTIALLY/DOES_NOT/NOT_VERIFIED` |
| `academic/engines/integrity-pipeline.js` | `runAcademicValidationPipeline({secs,datasets,metodologia})` | 15 etapas, `score`, `blocked=critical>0&&isStrict()`, `computeFinalGate` |
| `academic/engines/integrity-pipeline.js` | `computeFinalGate(report,ctx)` | Gate FINAL 7 regras → `blocked/canExportFinal/reasons` |
| `academic/prompts/chapters.js` | `montarPromptCapitulo(opts)` | Monta prompt com STRICT block, `fontesContexto`, `subs`, anti-IA |
| `academic/prompts/references.js` | `montarPromptReferencias()` / `peneirarReferencias(texto)` | Gera prompt refs + valida forma `Author (Year).` |
| `js/generator.js` | `iniciarGer()` | Loop capítulos com retry, `attempts>=4 → _blocosFb` fallback |
| `js/generator.js` | `extrairAutoresCitados(texto)` | 3 regex para `Autor (Ano)` → alimenta `autoresCitados` de refs |
| `js/export.js` | `sanitizarConteudo(txt)` | Remove markdown/bullets/JSON leakage, normaliza quebras |
| `js/export.js` | `_expPDFExecutar(secs,meta)` | Ajusta PBE, chama `validar_integridade`, injeta `watermark DRAFT`, `gerarJanelaPDF` |
| `js/academic-ui.js` | `renderIntegrityPipelinePanel(report)` | Mostra `🚫 NÃO PRONTO PARA FINAL` vs `✓ Pronto` baseado em `canExportFinal` |
| `js/academic-ui.js` | `validarIntegridade()` | `POST validar_integridade {secs,metodologia,_gateCtx}` — fonte única |

---

## E. Problemas Encontrados

### P0 — crítico
- **P0-1 Fallback fake local** — `js/generator.js:869` `_blocosFb` gera `Silva (2020)` + `Santos (2019)` fictícios quando IA falha 4 vezes, entrega como `PRONTO ⚠` sem bloquear FINAL.
- **P0-2 STRICT gate bypass** — `api/engine.js:792` `if(ACADEMIC_INTEGRITY_MODE==='STRICT')` só substitui citações não verificadas; se `!==STRICT` inventa livremente.
- **P0-3 Verificação inflada** — `verification.js:11` fallback `partially_verified` se `title&&author&&year` presentes sem consultar CrossRef.
- **P0-4 Persistência best-effort** — `api/engine.js:715` `fetch source_claims` com `catch(()=>{})` 4s; Supabase down → capítulos com `DIRECTLY_SUPPORTS` sem rastro.

### P1 — alto
- **P1-1 Fallback refs inventadas** — `js/export.js:93 refGerarFallback()` 10 refs hardcode (`World Bank, UNESCO, Santos 2018...`) exportadas se `<8` refs.
- **P1-2 Validação só de forma** — `peneirarReferencias` `/^[\w]{3,120} \((19|20)dd)./` aceita fictício, rejeita `Apelido, I. (Ano)` válido.
- **P1-3 Extração citações falha** — `evidence.js:33` regex `1[0-9]{3}` perde `20xx`, `INE (2024)` uppercase não casa.
- **P1-4 DOC_MEMORY falha silenciosa** — `generator.js:264` 3 regex com grupos errados (`m[2]+m[3]`) → `autoresCitados=[]` → órfãs.
- **P1-5 Sanitização over-greedy** — `export.js:11 sanitizarConteudo` regex JSON `{\s*"chapter_id"...` pode deletar parágrafo legítimo com `{"title":`.

### P2 — médio
- Prompt contraditório: `STRICT` diz `use [CITAÇÃO A VERIFICAR]` mas `PERFIL_NIVEL` exige `OBRIGATÓRIO 1 citação/parágrafo` → LLM inventa.
- `repararAST` drops `p.length>15 && !LIXO_JSON` → perde parágrafos curtos legítimos.
- `truncar()` `lastIndexOf('. ')` pode cortar meio-frase.
- `transparencia=1` hardcoded em `integrity-pipeline.js:124` ignora contagem de placeholders.

### P3 — baixo
- `POOLS_ANTI_IA` rotação determinística `(n*7+s*3)%len` detectável.
- `blocosBalanceados` O(n²), falha em `'` single-quote.

---

## F. Problema de Geração Repetitiva

**Onde:** `js/generator.js:869-870` `_blocosFb`; `academic/prompts/system.js:9,14` `PERFIL_NIVEL` 4 templates; `academic/prompts/chapters.js:102` exemplo com `15%`/`3.2%`.

**Como:** Fallback usa `A literatura indica que ${s.toLowerCase()} é dimensão central. Segundo Silva (2020)...` + `Santos (2019) argumenta que ${s} não se dissocia... A evidência indica que...` — injeta `s` (título subtópico) em frases pré-definidas. `PERFIL_NIVEL` hardcode `"Segundo Cardoso (2019),..."` etc. LLM copia padrão quando `fontesContexto` vazio. `ABORDAGEM ANALÍTICA OBRIGATÓRIA` + `POOLS_ANTI_IA` com `pick()` rotativo ainda gera variação limitada.

---

## G. Problema de Citações

**Como sem fonte chega:** LLM vê `OBRIGATÓRIO ≥1 citação/parágrafo` sem `fontesContexto` verificado → inventa `Silva (2020)`; `extrairCitacao` aceita; `_expPDFExecutar` só bloqueava se `rep.blocked` (crítico) → `Santos (2019)` fictício passa. Fallback `_blocosFb` também injeta `Santos (2019)` sem `source_id`. `peneirarReferencias` aceita forma → `Santos (2019)` entra em `refsList.validas` como verificado. Somente `api/engine.js:792 STRICT gate` remove se autor não em `verifiedAuthors`, mas é bypassado fora de STRICT.

**Onde rastrear:** `api/engine.js:731 SOURCE_ID:`, `:792 gate`, `evidence.js:33`, `verification.js:11`, `search.js:12 source_id`.

---

## H. Problema de Placeholders

**Marcadores:** `[CITAÇÃO A VERIFICAR]`, `[DADO A VERIFICAR COM FONTE PRIMÁRIA]`, `[DADO NÃO VERIFICADO]`, `[EVIDÊNCIA INSUFICIENTE]`, `[RESULTADO SEM DATASET]`.

**Onde criados:** `academic/prompts/chapters.js:33,76,84,146` instrução STRICT; `api/engine.js:734` `fontesContexto` vazio → diretiva placeholder; `api/engine.js:810` replace de citação não verificada; `js/generator.js:869-870` fallback gera placeholders mas entrega como pronto.

**Mantidos/filtro:** `integrity-pipeline.js:124` `transparencia=1 TODO` não conta; `sanitizarConteudo` não remove `[CITAÇÃO...]`; `layout.js` renderiza no PDF/DOCX. `computeFinalGate` agora conta mas pipeline legado não bloqueava.

**Chegam ao final?** Sim — `_expPDFExecutar` antes só checava `rep.blocked`, não placeholders.

---

## I. Problema de Corrupção Textual

**Evidências:** `api/engine.js:75 repararAST` 4 tentativas silenciosas catch, `blocosBalanceados` falha em `'`; `extrairJSON` prefere último bloco `sections` perdendo anterior; `sanitizarConteudo` `replace(/\\"/g,'"')` desescapa; `truncar` corta word-count; `pbe:252 ratio slice` resume capítulos; `stream:false` mas `max_tokens 6000-12000` trunca → `JSON.parse` falha → fallback raw `split(/\n/)`.

**Padrões `Fsquisa/Santcxs/pmblema/s%bre`:** não há encoding explícito (usa UTF-8 mas `split(/\s+/)` + `replace` com regex `/[A-ZÁ...]/` pode corromper se LLM devolve bytes truncados; `layout.js:433 XML encoding=UTF-8` correto mas `sanitizarConteudo` `replace(/\\n/g,'\n')` após JSON leakage pode reintroduzir `\` + `n` separados.

---

## J. Quality Gate Atual

Ver tabela completa em `BUG_MAP.md` + seção 8 deste README. Resumo:

- Determinísticas: `citations count`, `refs forma`, `statistics numsSemFonte`, `datasets row_count`, `tables temTabela`, `STRICT forbidden` — `integrity-pipeline.js`.
- IA: `classificarClaim`, `verificarCoerenciaArgumentativa`, `simularProfessor`.
- Bloqueia FINAL (gate unificado `computeFinalGate`): `critical>0`, `fabricated>0`, `score<40`, **+ 7 novas: órfãs>0, source não verificado, sem evidência, FACT sem DIRECTLY/PARTIALLY, número sem evidência, ref sem source, HIGH/CRITICAL>0, no_objectives, quality<50**.
- Só warning: `SHORT_PARAGRAPHS`, `AST_REPAIRED`, `tabela sem dataset` (se não-STRICT).
- Status: `DRAFT/REVIEW_REQUIRED/ACADEMICALLY_READY/BLOCKED` (`policies/integrity.js:determinarEstadoDocumento` + `integrity-pipeline label`).

**Export verifica em:** `js/export.js:281 _expPDFExecutar → validar_integridade → watermark DRAFT` e `js/academic-ui.js:323 renderIntegrityPipelinePanel`.

---

## K. Dependências

```
source/academic/index.js (barrel)
source/academic/engines/* (search, verification, retrieval, claims, evidence, integrity-pipeline, quality, argumentation, diagnostic, versioning)
source/academic/policies/* (integrity, confidence-policy, coverage, scope)
source/academic/prompts/* (chapters, references, system, structure, editing, evaluation)
source/academic/schemas/* (evidence, reference, document)
source/api/engine.js + ai-router.js (health, webhooks opcionais)
source/js/{generator,export,academic-ui,editor,layout,state,doc-blocks,pbe}
source/supabase/migrations/0014_academic_integrity_strict.sql (+ 0015/0016 jobs)
source/package.json (engines node>=20) + vercel.json
source/test/*.mjs (integrity, global-integrity, e2e, evidence, generation...)
.env.example (sanitizado, sem secrets)
```

Omitidos (fora escopo): `js/admin.js`, `auth.js`, `chat.js` completo, `css/*`, `server.js` legacy, `supabase/backup/dados/*`.

---

## L. O que NÃO deve ser alterado

- Autenticação, pagamentos (`supabase/migrations/0001-0012`, `js/auth.js`, `supabase.js` RLS), planos/preços.
- Infra Vercel/Supabase secrets (`.env` real).
- `sw.js` PWA cache fora do motor (exceto bump versão se tocar `layout.js`).
- Conteúdo fora de `academic/` + `api/engine,ai-router` + `js/{generator,export,academic-ui,editor,layout}` sem auditoria.

Próximo agente: **não corrigir neste pacote** — implementar correções no projeto principal a partir de `BUG_MAP.md` + `TEST_CASES.md`.

