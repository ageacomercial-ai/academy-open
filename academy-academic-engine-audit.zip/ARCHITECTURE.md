# ARCHITECTURE — Motor Acadêmico ACADEMY

## 1. Visão Arquitetural

```
[Browser SPA] ── State (js/state.js) ── callAcademyAPI() ──► [Vercel api/engine.js]
                                              │                     │
                                              │              ┌──────┴──────┐
                                              │              │ ai-router.js│
                                              │              │ Ollama→OR   │
                                              │              └──────┬──────┘
                                              │                     │ LLM JSON
                                              │              ┌──────▼──────┐
                                              │              │ academic/*  │
                                              │              │ prompts/    │
                                              │              │ engines/    │
                                              │              │ policies/   │
                                              │              │ schemas/    │
                                              │              └──────┬──────┘
                                              │                     │ verify
                                              │              ┌──────▼──────┐
                                              │              │ 5 Providers │
                                              │              │ OpenAlex/CR │
                                              │              │ EuropePMC  │
                                              │              └──────┬──────┘
                                              │                     │ evidence
                                              │              ┌──────▼──────┐
                                              └──────────────│ Supabase    │
                                                             │ sources/    │
                                                             │ claims/     │
                                                             │ source_claim│
                                                             └─────────────┘
```

Deploy: `vercel.json` → `api/engine.js` (Node 20, 25 req/min rateLimit). Frontend estático `js/*` + `index.html` SPA hash routing (`js/navigation.js:irPara`).

---

## 2. Módulos

| Módulo | Arquivos | Depende de |
|---|---|---|
| **Planejamento** | `api/engine.js:doPlano/doEstrutura`, `academic/prompts/structure.js` | `academic/prompts/system.js:PERFIL_NIVEL`, `api/ai-router` |
| **Claims EVIDENCE-FIRST** | `academic/engines/claims.js:extrairClaims,gerarQueries` | `academic/policies/scope.js:determinarEscopo` |
| **Busca** | `academic/engines/search.js:searchAll,rankSources,dedup` | Fetch 5 APIs, `TIMEOUT 8s` |
| **Verificação** | `academic/engines/verification.js:verificarReferenciaOnline` | `api.crossref.org`, `openlibrary.org` |
| **Evidência** | `academic/engines/retrieval.js:retrieveSource,extractEvidence,verifyClaimSupport` | `Unpaywall`, `EuropePMC`, `source.abstract` |
| **Geração** | `api/engine.js:doCapitulo`, `academic/prompts/chapters.js:montarPromptCapitulo`, `js/generator.js:iniciarGer` | `academic/prompts/system.js:POOLS_ANTI_IA`, `api/ai-router:generate` |
| **Reparo** | `api/engine.js:repararAST,extrairJSON,blocosBalanceados` | — |
| **Referências** | `api/engine.js:doReferencias`, `academic/prompts/references.js:peneirarReferencias`, `academic/engines/references.js:parseReferencias` | `academic/schemas/reference.schema.js` |
| **Integridade** | `academic/engines/integrity-pipeline.js:runAcademicValidationPipeline,computeFinalGate` | `policies/confidence-policy,integrity,coverage` |
| **Qualidade** | `academic/engines/quality.js:gerarScorecard`, `academic/engines/argumentation.js` | `policies/integrity`, `coverage` |
| **Export** | `js/export.js:expPDF/_expPDFExecutar/refGateExportacao/sanitizarConteudo`, `js/layout.js:gerarJanelaPDF` | `js/pbe.js`, `js/doc-blocks.js` |
| **UI Acadêmica** | `js/academic-ui.js:analisarDocumento,renderIntegrityPipelinePanel,validarIntegridade` | `api/engine:analisar_documento/validar_integridade` |
| **Estado** | `js/state.js:State.get/set` | — |
| **Persistência** | `supabase/migrations/0014_academic_integrity_strict.sql` | Supabase REST `source_claims` |

---

## 3. Fluxo de Dados (Mermaid)

```mermaid
sequenceDiagram
  participant U as Utilizador (State.cfg tema/nivel)
  participant F as js/generator.js
  participant B as api/engine.js doCapitulo
  participant C as claims.js extrairClaims
  participant S as search.js searchAll
  participant V as verification.js verificarReferenciaOnline
  participant R as retrieval.js retrieve+verify
  participant P as prompts/chapters montarPromptCapitulo
  participant AI as ai-router generate
  participant J as engine repararAST/extrairJSON
  participant G as integrity-pipeline runAcademicValidationPipeline
  participant E as js/export _expPDFExecutar

  U->>F: tema, capTit, capSubs, pags
  F->>B: POST gerar_capitulo {tema,capNum,capTit,capSubs,palavras}
  B->>C: extrairClaims(tema,[capTit+subs])
  C-->>B: factualClaims requires_source
  B->>S: gerarQueries → searchAll (5 providers)
  S-->>B: fontesEncontradas[source_id]
  B->>V: verificarReferenciaOnline (CrossRef)
  V-->>B: fontesBibliograficamenteVerificadas
  B->>R: retrieveSource → extractEvidence → verifyClaimSupport
  R-->>B: fontesQueSustentamClaim (DIRECTLY/PARTIALLY)
  B->>B: persist source_claims (Supabase)
  B->>P: montarPromptCapitulo + fontesContexto
  P-->>B: prompt
  B->>AI: callAI [systemJSON + userPrompt] json_object
  AI-->>B: raw JSON string (possível CoT)
  B->>J: extrairJSON/blocosBalanceados → repararAST
  J-->>B: ast {sections:[{title,paragraphs}]}
  B->>B: STRICT gate replace unverified (Autor, Ano) → [CITAÇÃO A VERIFICAR]
  B-->>F: {ast, health, readiness, confidence, completeness}
  F->>G: validar_integridade {secs} / analisar_documento
  G-->>F: report {score, blocked, canExportFinal, finalReasons}
  F->>E: expPDF → validar_integridade → watermark DRAFT se !canExportFinal
```

---

## 4. Dependências (imports críticos)

```
api/engine.js
  ← academic/index.js (re-export)
    ← academic/engines/{claims,search,verification,retrieval,evidence,integrity-pipeline,quality,argumentation,diagnostic,versioning}
    ← academic/policies/{integrity,confidence-policy,coverage,scope}
    ← academic/prompts/{chapters,references,system,structure,editing,evaluation}
    ← academic/schemas/{evidence,reference,document}
  ← api/ai-router.js (generate, health)
  ← supabase REST (SUPABASE_URL/SERVICE_KEY)

js/generator.js
  ← js/state.js
  ← js/academic-ui.js (analisarDocumento via ACADEMY_ENGINE_URL)
  ← api/engine (callAcademyAPI)

js/export.js
  ← js/state.js, js/layout.js:gerarJanelaPDF, js/doc-blocks.js:docEstruturarSemantico, js/pbe.js:pbeMedirPaginas

js/academic-ui.js
  ← js/state.js, ACADEMY_ENGINE_URL, api/engine:analisar_documento/validar_integridade/verificar_referencias
```

`package.json` engines `node>=20`, deps: — (vanilla fetch), `vercel.json` routes `api/*.js`.

---

## 5. IA / Modelos

`api/ai-router.js:CFG` — hierarquia: `ollama (OPEN_SOURCE) → openrouter (only FREE) → existingFreeApi → openaiDirect`. `stream:false` sempre (evita chunk corruption). `modelForTier(tier)` `cheap/balanced/strong`, `MODEL_TIERS` com `nvidia/nemotron-3-ultra:free`, `openai/gpt-4o-mini` etc. `max_tokens` `6000-12000` / `temperature 0.65` capítulos, `0.4` refs, `response_format:{type:'json_object'}` com retry sem format se `json_validate_failed`. Telemetria em `academy_ai_logs`.

---

## 6. Armazenamento

- **Supabase** `supabase/migrations/0014_academic_integrity_strict.sql`: `sources(doi unique, verification_score, content_hash)`, `claims(claim_type 9, source_id FK, verification_status, confidence)`, `source_claims(source_id FK, claim_id FK, support_status ENUM DIRECTLY/PARTIALLY/CONTRADICTS/DOES_NOT/NOT_CHECKED, evidence_text, page, section, confidence)` N:N unique, `datasets/dataset_rows (hash)`, `results(value,unit,calculation,traceable)`, `generation_logs(source_ids[], claim_ids[], integrity_score)`.
- `State` frontend: `secs[] {num,titulo,c,conteudo}`, `cfg`, `diagnostic`, `refs[]`, `academicAnalysis`, `refVerification`.
- `versioning.js`: snapshots imutáveis `criarSnapshot/listar/reverterPara`.

---

## 7. Validações

- **Determinísticas:** `peneirarReferencias` forma, `detectarNumerosSuspeitos` `%|toneladas|habitantes`, `datasets row_count`, `temTabela regex`, `numsSemFonte` contexto sem `Fonte:`, `coverage` keyword matching.
- **IA:** `classificarClaim`, `verificarCoerenciaArgumentativa`, `simularProfessor`.
- **Gate FINAL:** `integrity-pipeline:computeFinalGate` 7 regras → `canExportFinal`. Ver `README seção J`.

---

## 8. Exportação

`js/export.js`:
- `REF_MIN=8` `refGateExportacao` modal se `<8`.
- `sanitizarConteudo` remove markdown/JSON leakage.
- `pbeMedirPaginas` ajusta ratio `targetWords/currentWords` antes de imprimir.
- `_expPDFExecutar` chama `validar_integridade` → `meta.watermark=true` + `DRAFT — REQUIRES VERIFICATION` CSS `pg-wm` se `!canExportFinal`.
- `gerarJanelaPDF` em `js/layout.js` injeta `window.print()` com `@page A4 3cm/2.5cm`, `Georgia/Cormorant`, TOC, cover, indents.

DOCX: `JSZip` `word/document.xml` com `w:sectPr A4`, `styles.xml`, `footer PAGE`.

---

## 9. Limitações arquiteturais atuais

- Dual source of truth legado: `analisar_documento` (quality) vs `validar_integridade` (pipeline) — unificado agora via `canExportFinal` mas frontend ainda chama ambos.
- Busca ≠ geração: `searchAll` rate-limited (429) pode deixar `fontesQueSustentamClaim=[]` → prompt sem fontes → LLM inventa se gate bypass.
- Schema drift: `claims.js CLAIM_TYPES 9` vs `evidence.schema CLAIM_TYPES 5`.
- Supabase write best-effort → perda de `source_claims` não bloqueia.

