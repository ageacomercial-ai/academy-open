/* academic/prompts/system.js
   Perfis, contexto geográfico, anti-IA — partilhado entre frontend e backend
============================================================================= */

/* ── Perfis por nível académico ── */
export const PERFIL_NIVEL = {
  'ensino médio': {
    profundidade: `Linguagem clara para estudantes 14-18 anos. Conceitos desde o básico. Para Ciências: fórmulas básicas com cada variável explicada. Exemplos reconhecíveis do contexto do tema. 3-4 parágrafos densos por subtópico.`,
    citacoes: `2-3 citações por subtópico formato (Apelido, Ano). Exemplo: "Segundo Cardoso (2019),..." ou "...processo fundamental (Lima & Santos, 2020)." OBRIGATÓRIO: pelo menos 1 citação em CADA parágrafo principal.`,
    refs_min: 8, refs_africanos: 2,
  },
  licenciatura: {
    profundidade: `Nível universitário 1º ciclo. Rigor conceptual. Análise crítica: comparar perspectivas de pelo menos 2 autores. Dados estatísticos e factos verificáveis com anos e instituições (contexto do tema). 4-5 parágrafos densos por subtópico.`,
    citacoes: `2-3 citações por subtópico. Exemplos: "De acordo com Ferreira (2021),..." / "(Neto, 2019; Costa, 2022)." / "Silva (2020, p.45) argumenta que..." OBRIGATÓRIO: pelo menos 1 citação em CADA parágrafo principal, não apenas no fim.`,
    refs_min: 10, refs_africanos: 3,
  },
  mestrado: {
    profundidade: `Pós-graduação. Confrontar teorias, identificar lacunas. Síntese original com voz argumentativa. OBRIGATÓRIO: pelo menos 1 tensão teórica por subtópico (Autor A defende X, Autor B argumenta Y). 5-7 parágrafos de alta densidade por subtópico.`,
    citacoes: `3-4 citações por subtópico, directas e indirectas alternadas. Citação directa: Segundo Lopes (2018, p.112), "a gestão estratégica implica..." Citação indirecta: (Banda, 2020; Kiala & Mabiala, 2021). OBRIGATÓRIO: 1 tensão teórica por subtópico.`,
    refs_min: 12, refs_africanos: 4,
  },
  doutoramento: {
    profundidade: `Investigação original. Mapear estado da arte, propor contribuição nova. Posicionamento epistemológico. Obras seminais + investigação recente (últimos 5 anos). OBRIGATÓRIO: identificar lacuna na literatura por subtópico. 6-8 parágrafos de alta densidade.`,
    citacoes: `4-6 citações por subtópico. Obras fundacionais E investigação recente. Exemplo: "A teoria de Bourdieu (1980) foi revisitada por Mabiala (2019), que argumenta..." OBRIGATÓRIO: lacuna na literatura por subtópico.`,
    refs_min: 15, refs_africanos: 5,
  },
};

/* ── Perfis por área ── */
export const PERFIL_AREA = {
  ciencias: {
    label: 'Ciências Naturais/Exactas',
    instrucoes: `ÁREA Ciências (Física, Química, Biologia, Matemática, Geologia):
- OBRIGATÓRIO para subtópicos quantitativos: fórmulas com notação correcta e variáveis explicadas
- Unidades de medida SI sempre que relevante
- Fenómenos observáveis relevantes ao tema
- Referências: Nature, Science, African Journal of Science
- PROIBIDO: referências de ciências sociais ou gestão sem nexo científico`,
  },
  humanidades: {
    label: 'Humanidades e Ciências Sociais',
    instrucoes: `ÁREA Humanidades (História, Filosofia, Literatura, Sociologia, Comunicação):
- Perspectiva histórica com datas e actores concretos do contexto
- Factos históricos verificáveis com anos e fontes
- Teorias sociais aplicadas ao contexto do tema
- Referências: revistas de ciências sociais, história africana, estudos lusófonos
- PROIBIDO: referências de engenharia ou saúde clínica`,
  },
  gestao: {
    label: 'Gestão e Economia',
    instrucoes: `ÁREA Gestão, Economia, Administração, Finanças, Marketing:
- Indicadores económicos verificáveis com anos e fontes
- Dados quantitativos com fontes e anos verificáveis
- Modelos de gestão: SWOT, Porter, Balanced Scorecard quando pertinente
- Exemplos de empresas e sectores relevantes ao tema
- Referências de revistas académicas reconhecidas na área
- PROIBIDO: referências de saúde, ciências naturais ou direito sem nexo`,
  },
  direito: {
    label: 'Direito e Ciências Jurídicas',
    instrucoes: `ÁREA Direito (Constitucional, Penal, Civil, Comercial, Administrativo):
- Citar artigos de lei relevantes com número e ano
- Legislação relevante ao tema
- Jurisprudência aplicável ao tema
- Referências jurídicas académicas reconhecidas
- PROIBIDO: referências de gestão, saúde ou engenharia sem nexo jurídico`,
  },
  saude: {
    label: 'Saúde e Ciências da Vida',
    instrucoes: `ÁREA Saúde (Medicina, Enfermagem, Farmácia, Saúde Pública, Nutrição):
- Dados epidemiológicos relevantes ao tema com fontes (OMS, estudos peer-reviewed)
- Dados MINSA/OMS com anos e províncias: "Segundo MINSA (2022), a mortalidade infantil..."
- Protocolos clínicos ou guidelines OMS quando pertinente
- Nomenclatura médica correcta com equivalente comum na primeira ocorrência
- Referências: Lancet, NEJM, revistas africanas de saúde, publicações MINSA/OMS
- PROIBIDO: referências de gestão empresarial ou direito sem nexo clínico`,
  },
  engenharia: {
    label: 'Engenharia e Tecnologia',
    instrucoes: `ÁREA Engenharia (Civil, Informática, Eléctrica, Mecânica, Petrolífera, TIC):
- OBRIGATÓRIO: especificações numéricas, normas técnicas (ISO, IEEE), unidades
- Dados técnicos e infra-estruturas relevantes ao tema
- Exemplos de empresas e sectores relevantes ao tema
- IEEE, ASME, revistas de engenharia internacionais reconhecidas
- PROIBIDO: referências de humanidades ou direito sem nexo tecnológico`,
  },
};

/* ── Detectores ── */
export function detectarNivel(n) {
  const s = (n||'').toLowerCase();
  if (/médio|secundário|12\.º|11\.º|10\.º|\b12\b|\b11\b|\b10\b/.test(s)) return 'ensino médio';
  if (/mestrado|2\.º ciclo|pós.grad/.test(s)) return 'mestrado';
  if (/doutoramento|doutorado|phd|3\.º ciclo/.test(s)) return 'doutoramento';
  return 'licenciatura';
}

export function detectarArea(tema, areaParam) {
  if (areaParam && PERFIL_AREA[areaParam.toLowerCase()]) return areaParam.toLowerCase();
  const t = (tema||'').toLowerCase();
  if (/física|química|biologia|matemática|geologia|ecologia|botânica|astronomia/.test(t)) return 'ciencias';
  if (/direito|lei\b|jurídic|constitucional|penal|civil|comercial|legisl|tribunal/.test(t)) return 'direito';
  if (/saúde|médic|enfermagem|farmáci|hospital|doença|paludismo|nutrição|clínic/.test(t)) return 'saude';
  if (/gestão|economia|finanças|marketing|contabilidade|administração|empresa|negócio|empreendedorismo/.test(t)) return 'gestao';
  if (/engenharia|informática|software|hardware|eléctric|mecânic|construção|telecomunic|tic\b/.test(t)) return 'engenharia';
  return 'humanidades';
}

export const PLATFORM_SCOPE = 'GLOBAL';

export function detectarContextoGeo(tema, pais) {
  // PLATFORM_SCOPE = GLOBAL — nunca presumir Angola; escopo vem do TEMA, não da plataforma/usuário
  // pais (usuário) é IGNORADO — ver academic/policies/scope.js: usuarioNaoEhObjeto
  const t = (tema||'').toLowerCase();
  if (/angola|luanda|benguela|huambo|cabinda|namibe|malanje/.test(t)) return 'angola';
  if (/cabo.?verde|mindelo|praia|fogo|sal\b|barlavento/.test(t)) return 'cabo_verde';
  if (/moçambique|mozambique|maputo|beira\b|nampula/.test(t)) return 'mocambique';
  if (/brasil|são paulo|rio de janeiro|brasília|nordeste/.test(t)) return 'brasil';
  if (/portugal|lisboa|porto\b|coimbra|algarve/.test(t)) return 'portugal';
  if (/africa do sul|joanesburgo|cape town|pretória/.test(t)) return 'africa_sul';
  if (/estados unidos|eua|usa|new york|washington|california/.test(t)) return 'eua';
  if (/europa|ue\b|união europeia|berlim|paris|madrid|roma\b/.test(t)) return 'europa';
  if (/china|beijing|xangai|asia\b|japão|índia/.test(t)) return 'asia';
  if (/africa\b|africano|subsaariana|continente africano/.test(t)) return 'africa_geral';
  // pais ignorado — PLATFORM_SCOPE GLOBAL
  return 'global';
}

/* ── Pools anti-IA ── */
export const POOLS_ANTI_IA = {
  exemplos: [
    'A investigação académica demonstra que',
    'No contexto em análise,',
    'Num cenário concreto verificável,',
    'Os dados de campo indicam que',
    'A evidência empírica revela que',
    'Tomando como caso ilustrativo',
    'A evidência empírica mostra que',
    'Num contexto prático verificável,',
    'A análise do caso em estudo revela',
    'Os indicadores disponíveis mostram que',
    'O tema em análise ilustra bem',
    'Verificando os dados disponíveis,',
  ],
  hipoteses: [
    'A tese central deste trabalho é que',
    'A análise conduz à conclusão de que',
    'Os dados permitem inferir que',
    'A investigação aponta para o facto de que',
    'O exame crítico da literatura revela que',
    'A posição defendida neste estudo é que',
    'A leitura dos factos sugere que',
    'A evidência disponível indica que',
  ],
  conclusoes: [
    'A análise evidencia, portanto, que',
    'Os dados apresentados confirmam que',
    'O exame crítico demonstra que',
    'A síntese dos argumentos aponta para',
    'O quadro analítico traçado revela que',
    'A investigação permite concluir que',
    'Os elementos reunidos sustentam que',
    'O percurso argumentativo culmina em',
  ],
  transicoes: [
    'Aprofundando esta perspectiva,',
    'A análise revela ainda que',
    'Numa leitura mais crítica,',
    'Articulando com o argumento anterior,',
    'A dimensão analítica exige reconhecer que',
    'Complementando a perspectiva teórica,',
    'O debate académico evidencia que',
    'A revisão da literatura aponta que',
  ],
  conectores_proibidos: [
    'Cumpre referir que','Importa sublinhar que','Convém notar que',
    'Vale a pena salientar que','É relevante destacar que',
    'Neste sentido,','Neste quadro,','A este respeito,',
    'Do exposto decorre que','Perante o analisado,',
  ],
};

/* ── Instruções anti-IA (única fonte de verdade — frontend e backend) ── */
export function gerarInstrucaoAntiIA(capNum, totalCaps, geoInstrucao, pAreaLabel = '') {
  const n = Math.max(0, (capNum||1) - 1);
  // BUG-009: a versão antiga usava pick() para escolher UMA ÚNICA frase por
  // categoria e mandava "usa esta expressão" — como o prompt é emitido UMA VEZ
  // por capítulo inteiro (que contém vários subtópicos gerados na mesma
  // chamada), isso instruía o modelo a repetir a MESMA fórmula em todos os
  // subtópicos desse capítulo ("3.1 → fórmula A, 3.2 → fórmula A..."),
  // exactamente o padrão que o prompt mestre pede para eliminar. Agora
  // oferece-se um CONJUNTO rotativo (ainda determinístico por capítulo, para
  // não repetir entre capítulos) e instrui-se explicitamente a nunca reusar a
  // mesma dentro do mesmo capítulo.
  const pickSet = (arr, s, count = 4) => {
    const start = (n * 7 + s * 3) % arr.length;
    const out = [];
    for (let i = 0; i < Math.min(count, arr.length); i++) out.push(arr[(start + i) % arr.length]);
    return out;
  };
  const pools = POOLS_ANTI_IA;
  const fase = !totalCaps||totalCaps<=1 ? 'análise' :
    (n/(totalCaps-1))<=0.1 ? 'introdução' :
    (n/(totalCaps-1))<=0.35 ? 'fundamentação teórica' :
    (n/(totalCaps-1))<=0.65 ? 'análise crítica' :
    (n/(totalCaps-1))<=0.88 ? 'síntese' : 'conclusão';
  const proibidos = pools.conectores_proibidos.slice(0,4).join('", "');
  const exemplosSet   = pickSet(pools.exemplos, 1).map(e => `"${e}"`).join(', ');
  const hipotesesSet  = pickSet(pools.hipoteses, 2).map(e => `"${e}"`).join(', ');
  const conclusoesSet = pickSet(pools.conclusoes, 3).map(e => `"${e}"`).join(', ');
  const transicoesSet = pickSet(pools.transicoes, 4).map(e => `"${e}"`).join(', ');
  return `REGRAS DE ESTILO OBRIGATÓRIAS — APLICAR RIGOROSAMENTE:

TOM E VOZ:
1. Escreve com VOZ ANALÍTICA — não apenas descrever conceitos, mas comparar, questionar, posicionar
2. Cada subtópico deve incluir: (a) posição teórica, (b) contraponto ou limitação, (c) aplicação ao contexto do tema
3. PROIBIDO usar estes conectores mecânicos que revelam texto IA: "${proibidos}"
4. PROIBIDO iniciar dois parágrafos consecutivos com a mesma palavra ou estrutura
5. Para exemplos, ROTA entre estas opções — nunca a mesma duas vezes no mesmo capítulo, nunca todas no mesmo subtópico: ${exemplosSet}
6. Para hipótese/posição, ROTA entre: ${hipotesesSet}
7. Para concluir, ROTA entre: ${conclusoesSet}
8. Para transições, ROTA entre: ${transicoesSet}
8b. CADA SUBTÓPICO (3.1, 3.2, 3.3...) deve usar uma opção DIFERENTE de cada lista acima — se o subtópico anterior usou a 1ª opção, o seguinte usa a 2ª, e assim sucessivamente. Nunca repetir a mesma expressão em dois subtópicos consecutivos do mesmo capítulo.

ANTI-DETECÇÃO IA — PROIBIÇÕES ABSOLUTAS:
9. NUNCA uses frases genéricas tipo: "É importante salientar que...", "Vale a pena referir que...", "Neste contexto..."
10. NUNCA uses "actualmente", "hoje em dia", "era uma vez", "desde sempre" — usa datas específicas
11. NUNCA uses "diversos estudos", "várias investigações", "muitos autores" — cita sempre nomes concretos
12. NUNCA uses "por um lado... por outro lado" — usa contraste direto entre autores
13. NUNCA uses "em suma", "em jeito de conclusão", "para finalizar" — termina o argumento naturalmente
14. Varia a EXTENSÃO dos parágrafos: uns com 4 frases, outros com 6-7, outros com 3 — ritmo humano
15. Inclui pelo menos 1 dado quantitativo concreto por subtópico (percentagem, ano, número)

CITAÇÕES — OBRIGATÓRIO:
16. Cada dado estatístico DEVE ter citação inline: (Autor, Ano) ou (Instituição, Ano)
17. Não escrever "segundo dados do INE" sem especificar o ano: "segundo INE (2023)"
18. Mínimo 2 citações por parágrafo de desenvolvimento — integradas no argumento, não no fim
19. Alterna entre citação direta ("Autor (Ano, p.X) afirma que...") e indireta ("...conforme demonstrado por Autor (Ano)")
20. Nunca cites o mesmo autor mais de 3 vezes no capítulo — diversifica as fontes

CONTEXTO GEOGRÁFICO: ${geoInstrucao}

POSIÇÃO NO DOCUMENTO: ${fase} — adequa profundidade analítica

PROIBIÇÕES DE VOCABULÁRIO IA (NUNCA usar):
- "multifacetado", "complexo", "dinâmico", "abrangente", "significativo", "relevante", "importante"
- "paradigma", "ecossistema", "alavancagem", "ucket", "engajamento", "impactante"
- "sob a ótica", "sob a perspectiva", "no âmbito", "à luz de", "em face de"
Substitui por termos específicos da área${pAreaLabel ? ': ' + pAreaLabel : ''}`;
}

/* ── Contexto geográfico — PLATFORM_SCOPE = GLOBAL ── */
export function gerarInstrucaoGeo(tema, pais, geoCtx) {
  const ctx = geoCtx || detectarContextoGeo(tema, pais);
  const baseGlobal = 'A ACADEMY É PLATAFORMA ACADÊMICA GLOBAL (PLATFORM_SCOPE=GLOBAL). NUNCA presuma Angola. O escopo vem do TEMA/OBJETIVOS, não da plataforma/usuário/idioma. ';
  if (ctx === 'angola') return baseGlobal + 'O tema foca Angola — use fontes angolanas + africanas + internacionais relevantes quando sustentarem o claim (priorize dados angolanos sempre que existam e estejam verificados). Internacional é válido para Angola.';
  if (ctx === 'cabo_verde') return baseGlobal + 'O tema foca Cabo Verde — use fontes cabo-verdianas + internacionais relevantes.';
  if (ctx === 'brasil') return baseGlobal + 'O tema foca Brasil — use fontes brasileiras + internacionais relevantes.';
  if (ctx === 'portugal') return baseGlobal + 'O tema foca Portugal — use fontes portuguesas + internacionais relevantes.';
  if (ctx === 'eua' || ctx === 'europa' || ctx === 'asia' || ctx === 'africa_geral') return baseGlobal + `O tema foca ${ctx} — use fontes dessa região + literatura global. Nunca restrinja a Angola.`;
  return baseGlobal + 'Tema global/universal — priorize literatura internacional, meta-análises, WB/UN/UNESCO/WHO/ITU/OECD e revistas globais. Nunca insira Angola por padrão. Melhor fonte disponível para cada claim, não fonte do país da plataforma.';
}
